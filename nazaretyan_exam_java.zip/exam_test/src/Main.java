//1 ЧАСТЬ
//1
//import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Введите первое число: ");
//        int num1 = scanner.nextInt();
//
//        System.out.print("Введите второе число: ");
//        int num2 = scanner.nextInt();
//
//        System.out.print("Введите третье число: ");
//        int num3 = scanner.nextInt();
//
//        System.out.print("Введите четвёртое число: ");
//        int num4 = scanner.nextInt();
//
//        int max = num1;
//
//        if (num2 > max) max = num2;
//        if (num3 > max) max = num3;
//        if (num4 > max) max = num4;
//
//        System.out.println("Максимальное число: " + max);
//        scanner.close();
//    }
//}
//
//
//2
//import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Введите 1 число: ");
//        int a = scanner.nextInt();
//
//        System.out.print("Введите 2 число: ");
//        int b = scanner.nextInt();
//
//        for (int i = a; i <= b; i++) {
//            System.out.println(i);
//        }
//
//        scanner.close();
//    }
//}
//
//3
//import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("Введите размер стороны квадрата: ");
//        int size = scanner.nextInt();
//
//        for (int i = 0; i < size; i++) {
//            for (int j = 0; j < size; j++) {
//                System.out.print("* ");
//            }
//            System.out.println();
//        }
//        scanner.close();
//    }
//}
//
//4
//import java.math.BigInteger;
//
//public class Main {
//    public static void main(String[] args) {
//        BigInteger product = BigInteger.ONE;
//        for (int i = 40; i <= 85; i++) {
//            product = product.multiply(BigInteger.valueOf(i));
//        }
//        System.out.println("Произведение целых чисел от 40 до 85 равно: " + product);
//    }
//}
//
//5
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Random;
//
//public class Main {
//
//    public static void main(String[] args) {
//        List<Integer> numbers = new ArrayList<>();
//
//        Random random = new Random();
//
//        for (int i = 0; i < 10; i++) {
//            int randomNumber = random.nextInt(100) + 1;
//            numbers.add(randomNumber);
//        }
//
//        System.out.print("Элементы списка: ");
//        for (int number : numbers) {
//            System.out.print(number + " ");
//        }
//        System.out.println();
//    }
//}
//
//6
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Random;
//
//public class Main {
//
//    public static void main(String[] args) {
//        List<Integer> numbers = new ArrayList<>();
//
//        Random random = new Random();
//
//        for (int i = 0; i < 10; i++) {
//            int randomNumber = random.nextInt(100) + 1;
//            numbers.add(randomNumber);
//        }
//
//        System.out.print("Элементы списка: ");
//        for (int number : numbers) {
//            System.out.print(number + " ");
//        }
//        System.out.println();
//
//
//        double sum = 0.0;
//        for (int number : numbers) {
//            sum += number;
//        }
//        double average = sum / numbers.size();
//
//        System.out.printf("Среднее арифметическое: " + average);
//    }
//}
//
//2 ЧАСТЬ
//1
//import java.util.Scanner;
//
//public class Main {
//
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Введите предложение: ");
//        String input = scanner.nextLine();
//
//        String[] words = input.trim().split("\\s+");
//
//        int wordCount = 0;
//
//        for (String word : words) {
//            if (!word.matches("\\d+")) {
//                wordCount++;
//            }
//        }
//
//        System.out.println(wordCount + " слов");
//    }
//}
//
//2
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        List<Integer> numbers = new ArrayList<>();
//
//        System.out.println("Введите целые числа (введите 'стоп' для завершения ввода):");
//
//        while (true) {
//            String input = scanner.nextLine();
//
//            if (input.equalsIgnoreCase("стоп")) {
//                break;
//            }
//
//            try {
//                int number = Integer.parseInt(input);
//                numbers.add(number);
//            } catch (NumberFormatException e) {
//                System.out.println("Введено не число. ");
//            }
//        }
//
//
//        System.out.println("Список чисел: " + numbers);
//
//
//        int sum = 0;
//        for (int number : numbers) {
//            sum += number;
//        }
//
//        System.out.println("Сумма чисел: " + sum);
//    }
//}
//
//3
//import java.util.ArrayList;
//import java.util.List;
//
//public class Main {
//    public static void main(String[] args) {
//        List<String> firstList = new ArrayList<>();
//        firstList.add("яблоко");
//        firstList.add("банан");
//        firstList.add("вишня");
//        firstList.add("апельсин");
//        firstList.add("мандарин");
//        firstList.add("груша");
//        firstList.add("персик");
//        firstList.add("слива");
//        firstList.add("клубника");
//        firstList.add("малина");
//
//        List<String> secondList = new ArrayList<>();
//        secondList.add("банан");
//        secondList.add("вишня");
//        secondList.add("персик");
//
//        System.out.println("Первый список до удаления: " + firstList);
//        firstList.removeAll(secondList);
//
//        System.out.println("Первый список после удаления: " + firstList);
//        System.out.println("Второй список: " + secondList);
//    }
//}
//
//3 ЧАСТЬ
//1
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//
//class Product {
//    private String name;
//    private double price;
//
//    public Product(String name, double price) {
//        this.name = name;
//        this.price = price;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public double getPrice() {
//        return price;
//    }
//
//    @Override
//    public String toString() {
//        return name + " - " + price + " руб.";
//    }
//}
//
//class ShoppingCart {
//    private List<Product> products;
//
//    public ShoppingCart() {
//        this.products = new ArrayList<>();
//    }
//
//    public void addProduct(Product product) {
//        products.add(product);
//        System.out.println("Товар добавлен в корзину: " + product);
//    }
//
//    public void removeProduct(int index) {
//        if (index >= 0 && index < products.size()) {
//            Product removedProduct = products.remove(index);
//            System.out.println("Товар удален из корзины: " + removedProduct);
//        } else {
//            System.out.println("Ошибка: Неверный номер товара.");
//        }
//    }
//
//    public void displayProducts() {
//        if (products.isEmpty()) {
//            System.out.println("Корзина пуста.");
//        } else {
//            System.out.println("Товары в корзине:");
//            for (int i = 0; i < products.size(); i++) {
//                System.out.println((i + 1) + ". " + products.get(i));
//            }
//        }
//    }
//
//    public double calculateTotal() {
//        double total = 0;
//        for (Product product : products) {
//            total += product.getPrice();
//        }
//        return total;
//    }
//}
//
//public class Main {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        ShoppingCart cart = new ShoppingCart();
//        int choice;
//
//        do {
//            System.out.println("\nМеню:");
//            System.out.println("1. Добавить товар в корзину");
//            System.out.println("2. Удалить товар из корзины");
//            System.out.println("3. Вывести все товары в корзине");
//            System.out.println("4. Посчитать стоимость всех товаров в корзине");
//            System.out.println("5. Выйти");
//            System.out.print("Введите ваш выбор: ");
//            choice = scanner.nextInt();
//            scanner.nextLine();
//
//            switch (choice) {
//                case 1:
//                    System.out.print("Введите название товара: ");
//                    String name = scanner.nextLine();
//                    System.out.print("Введите цену товара: ");
//                    double price = scanner.nextDouble();
//                    cart.addProduct(new Product(name, price));
//                    break;
//                case 2:
//                    cart.displayProducts();
//                    System.out.print("Введите номер товара для удаления: ");
//                    int indexToRemove = scanner.nextInt() - 1;
//                    cart.removeProduct(indexToRemove);
//                    break;
//                case 3:
//                    cart.displayProducts();
//                    break;
//                case 4:
//                    double total = cart.calculateTotal();
//                    System.out.println("Стоимость всех товаров в корзине: " + total + " руб.");
//                    break;
//                case 5:
//                    System.out.println("Выход");
//                    break;
//                default:
//                    System.out.println("Неверный выбор");
//            }
//        } while (choice != 5);
//
//        scanner.close();
//    }
//}